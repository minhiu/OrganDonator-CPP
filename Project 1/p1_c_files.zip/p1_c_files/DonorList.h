#ifndef DONORLIST_H
#define DONORLIST_H

#include "DonorType.h"

#include<iostream>
#include <string>		
#include <iomanip>

using namespace std;

const int CAP = 20;

class DonorList
{
public:
	
	// Declarations public member functions

private:

	// Declaration private member function

	DonorType *list;
	int capacity;
	int numOfElem;		
};

#endif

