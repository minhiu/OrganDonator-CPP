#include "DonorList.h"

// Definition default constructor


// Definition overloaded constructor


// Definition member function addDonor


// Definition member function getNumberOfDonors


// Definition member function getTotalDonations


// Definition member function getHighestDonation


// Definition member function isEmpty


// Definition member function searchID


// Definition member function searchName


// Definition member function deleteDonor


// Definition member function emptyList


// Definition member function printDonorByName


// Definition member function printDonor


// Definition member function printDonation


// Definition member function printTotalDonations


// Definition member function printHighestDonation


// Definition destructor


// Definition member function resizeList
